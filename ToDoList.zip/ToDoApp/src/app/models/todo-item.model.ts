export class TodoItem {
    itemId: number=0;
    itemName: string="";
    itemDescription: string="";
    itemStatus: boolean=false;
}
